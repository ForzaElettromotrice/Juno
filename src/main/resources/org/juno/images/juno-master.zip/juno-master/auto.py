# Run as: blender -b <filename> -P <this_script>
import bpy, os

if not os.path.exists('output'):
    os.makedirs('output')

input_path = '/home/andrea/blender/juno/template'
output_path = 'output'

colors = {'r': (0.107, 0.002, 0.002, 1),
          'g': (0, 0.366, 0.001, 1),
          'b': (0, 0.027, 0.571, 1),
          'y': (0.571, 0.462, 0, 1)}

mat = bpy.data.materials['Material.006']


for c in colors:
    mat.node_tree.nodes['Anisotropic BSDF'].inputs['Color'].default_value = colors[c]
    for t in os.listdir(input_path):
        im = bpy.data.images.load(os.path.join(input_path, t))
        mat.node_tree.nodes['Image Texture'].image = im
        render_name = c + os.path.splitext(t)[0]
        bpy.context.scene.render.filepath = os.path.join(output_path, render_name)
        # Render still image, automatically write to output path
        bpy.ops.render.render(write_still=True)

